GlowPadView Library  
====
  
The GlowPadView library is basically Android's Lock Ring (way of screen-unlocking and alarm dismissing), but extended and targeted to Honeycomb and later versions of Android.
I tried getting it to run on Gingerbread, but even NineOldAndroids (http://nineoldandroids.com/) didn't give me everything I needed.

![Example image](https://raw.github.com/nadavfima/GlowPadView/master/example.png)


Copyright and Licensing
----

Copyright Nadav Fima © 2012. All rights reserved.